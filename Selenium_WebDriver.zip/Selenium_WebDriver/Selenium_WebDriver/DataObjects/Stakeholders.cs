﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Selenium_WebDriver
{
    public class Stakeholders
    {
        private IWebDriver driver;

        public Stakeholders(IWebDriver driver)
        {
            this.driver = driver;
        }

        public void StakeholderCreate(int load)
        {
            Thread.Sleep(1000);
            SetMethods.Click(driver, "layout_stake_a", "id");
            Thread.Sleep(100);
            SetMethods.Click(driver, "//div[@id='StakeholderGrid']/div/div/a/i", "xpath");
            Thread.Sleep(100);
            SetMethods.Click(driver, "Stakeholder_Name", "id");
            SetMethods.EnterText(driver, "Stakeholder_Name", RandomStringGenerators.randomStringGenerator(6, "caps").ToString(), "id");
            SetMethods.Click(driver, "Stakeholder_EmailId", "id");
            SetMethods.EnterText(driver, "Stakeholder_EmailId", ExcelUtility.ReadData(load, "Stakeholder_EmailId").ToString(), "id");
            SetMethods.Click(driver, "Stakeholder_Website", "id");
            SetMethods.EnterText(driver, "Stakeholder_Website", ExcelUtility.ReadData(load, "Stakeholder_Website").ToString(), "id");

            SetMethods.Click(driver, "//div[@id='tab1']/div[2]/div[1]/div/div/span[1]/span/span[1]", "xpath");
            Thread.Sleep(100);
            driver.FindElement(By.XPath("//div[@id='Stakeholder_LanguageId-list']")).FindElement(By.XPath("//ul[@id='Stakeholder_LanguageId_listbox']/li[2]")).Click();

            SetMethods.Click(driver, "//div[@id='tab1']/div[2]/div[2]/div/div/span[1]/span/span[1]", "xpath");
            Thread.Sleep(100);
            driver.FindElement(By.XPath("//div[@id='Stakeholder_Size-list']")).FindElement(By.XPath("//ul[@id='Stakeholder_Size_listbox']/li[4]")).Click();

            SetMethods.Click(driver, "Stakeholder_PrimaryPhone", "id");
            SetMethods.EnterText(driver, "Stakeholder_PrimaryPhone", ExcelUtility.ReadData(load, "Stakeholder_PrimaryPhone").ToString(), "id");

            SetMethods.Click(driver, "//div[@id='tab1']/div[3]/div/div/div/span/span/span", "xpath");
            Thread.Sleep(100);
            driver.FindElement(By.XPath("//div[@id='Stakeholder_TypeId-list']")).FindElement(By.XPath("//ul[@id='Stakeholder_TypeId_listbox']/li[4]")).Click();

            SetMethods.Click(driver, "//div[@id='Stakeholder_Trade_input']/div/span[1]/span/span[2]/span", "xpath");
            Thread.Sleep(100);
            driver.FindElement(By.XPath("//div[@id='Stakeholder_Trade-list']")).FindElement(By.XPath("//ul[@id='Stakeholder_Trade_listbox']/li[4]")).Click();

            SetMethods.Click(driver, "//body", "xpath");
            SetMethods.Click(driver, "//a[contains(text(),'Next')]", "xpath");
            Thread.Sleep(2000);

            //create a address by entering each column in address page with a load '3'
            Address stakeholderAddress = new Address(driver);
            stakeholderAddress.AddressEntryByEachColumn(3);

            SetMethods.Click(driver, "//a[contains(text(),'Next')]", "xpath");
            Thread.Sleep(3000);
            SetMethods.Click(driver, "Save", "link");
            Thread.Sleep(5000);
            SetMethods.Click(driver, "//div[@id='StakeholdersContactGrid']/div/div/a/i", "xpath");

            //create a contact
            Thread.Sleep(2000);
            Contact contact = new Contact(driver);
            contact.ContactCreate();
            Thread.Sleep(2000);
            // StakeholderGrid
            //SetMethods.Click(driver, "//div[@id='StakeholderGrid']/div[3]/table/tbody/tr/td[6]", "xpath");
        }




    }
}

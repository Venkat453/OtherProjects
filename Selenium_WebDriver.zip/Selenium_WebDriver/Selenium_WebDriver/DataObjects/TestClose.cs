﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Selenium_WebDriver
{
    public class TestClose
    {
        private IWebDriver driver;

        public TestClose(IWebDriver driver)
        {
            this.driver = driver;
        }

        public void TestCloseUp()
        {
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//a[@id='layout_home_a']/span[2]")).Click();
            driver.FindElement(By.XPath("(//a[@id='navLogin']/i)[2]")).Click();
            Thread.Sleep(1000);
            driver.Close();
        }
    }
}

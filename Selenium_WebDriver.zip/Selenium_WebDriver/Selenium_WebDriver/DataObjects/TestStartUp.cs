﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Selenium_WebDriver
{
    public class TestStartUp
    {
        private IWebDriver driver;

        public TestStartUp(IWebDriver driver)
        {
            this.driver = driver;
        }

        public void testStartUp()
        {
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("http://test.cmacspro.com//Home/Index/landing");

            //SetMethods.Click(driver, "Email", "id");
            SetMethods.EnterText(driver, "Email", "proadmin@cmacspro.com", "id");
            //SetMethods.Click(driver, "Password", "id");
            SetMethods.EnterText(driver, "Password", "Plan!F@b", "id");

            SetMethods.Click(driver, "//input[@value='Log in']", "xpath");
            Thread.Sleep(1000);
            SetMethods.Click(driver, "//a[@id='layout_home_a']/span[2]", "xpath");
        }

    }
}

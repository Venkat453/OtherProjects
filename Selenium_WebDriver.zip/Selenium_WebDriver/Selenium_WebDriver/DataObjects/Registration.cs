﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Selenium_WebDriver
{
    public class Registration
    {
        private IWebDriver driver;

        public Registration(IWebDriver driver)
        {
            this.driver = driver;
        }

        public void Register(int load)
        {
            // Open URL;
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("http://test.cmacspro.com/Register/Index");
            Thread.Sleep(200);
            // Tab1
            SetMethods.Click(driver, "Customer_Name", "id");
            SetMethods.EnterText(driver, "Customer_Name", RandomStringGenerators.randomStringGenerator(6, "caps").ToString(), "id");
            SetMethods.Click(driver, "Customer_EmailId", "id");
            SetMethods.EnterText(driver, "Customer_EmailId", RandomStringGenerators.randomEmailGenerator(8).ToString(), "id");
            SetMethods.Click(driver, "Customer_Website", "id");
            SetMethods.EnterText(driver, "Customer_Website", "www" + RandomStringGenerators.randomStringGenerator(6, "small").ToString() + ".com", "id");
            SetMethods.Click(driver, "Customer_Industry", "id");
            SetMethods.EnterText(driver, "Customer_Industry", RandomStringGenerators.randomStringGenerator(7, "caps").ToString(), "id");

            SetMethods.Click(driver, "//div[@id='tab1']/div[2]/div[2]/div/div/span/span/span", "xpath");
            Thread.Sleep(100);
            driver.FindElement(By.XPath("//div[@id='Customer_Size-list']")).FindElement(By.XPath("//ul[@id='Customer_Size_listbox']/li[5]")).Click();
            //SetMethods.Click(driver, "//ul[@id='Customer_Size_listbox']/li[5]", "xpath");
            SetMethods.Click(driver, "//div[@id='tab1']/div[2]/div[3]/div/div/span/span/span", "xpath");
            Thread.Sleep(100);
            driver.FindElement(By.XPath("//div[@id='Customer_LanguageId-list']")).FindElement(By.XPath("//ul[@id='Customer_LanguageId_listbox']/li[2]")).Click();
            //SetMethods.Click(driver, "//ul[@id='Customer_LanguageId_listbox']/li[2]", "xpath");

            SetMethods.Click(driver, "Customer_PrimaryPhone", "id");
            SetMethods.EnterText(driver, "Customer_PrimaryPhone", "+919889898989", "id");

            SetMethods.Click(driver, "//a[contains(text(),'Next')]", "xpath");
            Thread.Sleep(2000);
            // Tab 2
            //create a address by entering each column in address page with a load '3'
            Address stakeholderAddress = new Address(driver);
            stakeholderAddress.AddressEntryByEachColumn(load);


            SetMethods.Click(driver, "//a[contains(text(),'Next')]", "xpath");
            Thread.Sleep(3000);
            // Tab 3
            SetMethods.Click(driver, "Customer_TaxCode", "id");
            SetMethods.EnterText(driver, "Customer_TaxCode", RandomStringGenerators.randomStringGenerator(6, "aplhanumeric").ToString(), "id");

            SetMethods.Click(driver, "//div[@id='tab3']/div/div[2]/div/div/span/span/span", "xpath");
            Thread.Sleep(100);
            driver.FindElement(By.XPath("//div[@id='Customer_CurrencyId-list']")).FindElement(By.XPath("//ul[@id='Customer_CurrencyId_listbox']/li[2]")).Click();
            //SetMethods.Click(driver, "//ul[@id='Customer_CurrencyId_listbox']/li[2]", "xpath");

            SetMethods.Click(driver, "//a[contains(text(),'Next')]", "xpath");
            Thread.Sleep(1000);
            // Tab 4
            SetMethods.Click(driver, "Customer_Categories", "id");
            SetMethods.EnterText(driver, "Customer_Categories", RandomStringGenerators.randomStringGenerator(6, "small").ToString(), "id");

            SetMethods.Click(driver, "//a[contains(text(),'Next')]", "xpath");
            Thread.Sleep(200);

            // Tab 5
            SetMethods.Click(driver, "Contact_FirstName", "id");
            SetMethods.EnterText(driver, "Contact_FirstName", RandomStringGenerators.randomStringGenerator(6, "caps").ToString(), "id");
            SetMethods.Click(driver, "Contact_MiddleName", "id");
            SetMethods.EnterText(driver, "Contact_MiddleName", RandomStringGenerators.randomStringGenerator(6, "caps").ToString(), "id");
            SetMethods.Click(driver, "Contact_LastName", "id");
            SetMethods.EnterText(driver, "Contact_LastName", RandomStringGenerators.randomStringGenerator(6, "caps").ToString(), "id");

            SetMethods.Click(driver, "//div[@id='tab5']/div/div[2]/div/div/div/span/span/span[2]/span", "xpath");
            Thread.Sleep(100);
            driver.FindElement(By.XPath("//div[@id='Contact_Title-list']")).FindElement(By.XPath("//ul[@id='Contact_Title_listbox']/li[7]")).Click();
            //SetMethods.Click(driver, "//ul[@id='Contact_Title_listbox']/li[7]", "xpath");

            SetMethods.Click(driver, "Contact_Email", "id");
            SetMethods.EnterText(driver, "Contact_Email", RandomStringGenerators.randomEmailGenerator(8).ToString(), "id");
            SetMethods.Click(driver, "Contact_SecondaryEmail", "id");
            SetMethods.EnterText(driver, "Contact_SecondaryEmail", RandomStringGenerators.randomEmailGenerator(8).ToString(), "id");

            SetMethods.Click(driver, "Contact_Website", "id");
            SetMethods.EnterText(driver, "Contact_Website", "www" + RandomStringGenerators.randomStringGenerator(6, "small").ToString() + ".com", "id");
            SetMethods.Click(driver, "Contact_PrimaryPhone", "id");
            SetMethods.EnterText(driver, "Contact_PrimaryPhone", "+91 9889898989", "id");
            SetMethods.Click(driver, "Contact_SecondaryPhone", "id");
            SetMethods.EnterText(driver, "Contact_SecondaryPhone", "+91 9889676767", "id");
            SetMethods.Click(driver, "Contact_FaxNumber", "id");
            SetMethods.EnterText(driver, "Contact_FaxNumber", "+91 9889898989", "id");

            // Add address
            SetMethods.Click(driver, "addaddress", "id");
            Thread.Sleep(100);
            // Line1
            SetMethods.Click(driver, "//div[@id='newAddressDiv']/div/div[2]/div/div/div/input", "xpath");
            SetMethods.EnterText(driver, "//div[@id='newAddressDiv']/div/div[2]/div/div/div/input", RandomStringGenerators.randomStringGenerator(6, "small").ToString(), "xpath");
            // Line2
            SetMethods.Click(driver, "//div[@id='newAddressDiv']/div/div[2]/div[2]/div/div/input", "xpath");
            SetMethods.EnterText(driver, "//div[@id='newAddressDiv']/div/div[2]/div[2]/div/div/input", RandomStringGenerators.randomStringGenerator(6, "small").ToString(), "xpath");
            // Country
            SetMethods.Click(driver, "//div[@id='newAddressDiv']/div/div[2]/div[3]/div/div/input", "xpath");
            SetMethods.EnterText(driver, "//div[@id='newAddressDiv']/div/div[2]/div[3]/div/div/input", RandomStringGenerators.randomStringGenerator(6, "small").ToString(), "xpath");
            // City
            SetMethods.Click(driver, "//div[@id='newAddressDiv']/div/div[3]/div/div/div/input", "xpath");
            SetMethods.EnterText(driver, "//div[@id='newAddressDiv']/div/div[3]/div/div/div/input", RandomStringGenerators.randomStringGenerator(6, "small").ToString(), "xpath");
            // State
            SetMethods.Click(driver, "//div[@id='newAddressDiv']/div/div[3]/div[2]/div/div/input", "xpath");
            SetMethods.EnterText(driver, "//div[@id='newAddressDiv']/div/div[3]/div[2]/div/div/input", RandomStringGenerators.randomStringGenerator(6, "small").ToString(), "xpath");
            // County
            SetMethods.Click(driver, "//div[@id='newAddressDiv']/div/div[3]/div[3]/div/div/input", "xpath");
            SetMethods.EnterText(driver, "//div[@id='newAddressDiv']/div/div[3]/div[3]/div/div/input", RandomStringGenerators.randomStringGenerator(6, "small").ToString(), "xpath");
            // PostalCode
            SetMethods.Click(driver, "//div[@id='newAddressDiv']/div/div[4]/div/div/div/input", "xpath");
            SetMethods.EnterText(driver, "//div[@id='newAddressDiv']/div/div[4]/div/div/div/input", RandomStringGenerators.randomStringGenerator(6, "numeric").ToString(), "xpath");
            // AdditionalDetails
            SetMethods.Click(driver, "//div[@id='newAddressDiv']/div/div[4]/div[2]/div/div/input", "xpath");
            SetMethods.EnterText(driver, "//div[@id='newAddressDiv']/div/div[4]/div[2]/div/div/input", RandomStringGenerators.randomStringGenerator(6, "small").ToString(), "xpath");

            SetMethods.Click(driver, "//a[contains(text(),'Next')]", "xpath");
            Thread.Sleep(3000);
            SetMethods.Click(driver, "//a[contains(text(),'Save')]", "xpath");
            Thread.Sleep(32000);

            // Change Password
            SetMethods.Click(driver, "NewPassword", "id");
            SetMethods.EnterText(driver, "NewPassword", "Password1234!", "id");
            Thread.Sleep(100);
            SetMethods.Click(driver, "ConfirmPassword", "id");
            SetMethods.EnterText(driver, "ConfirmPassword", "Password1234!", "id");
            //choose language
            Thread.Sleep(100);
            SetMethods.Click(driver, "//form[@id='ChangeDefaultPassword']/div[2]/div[4]/div/div/div/span/span/span", "xpath");
            SetMethods.Click(driver, "//ul[@id='DefaultLanguage_listbox']/li[2]", "xpath");
            // Choose Time Zone
            Thread.Sleep(100);
            SetMethods.Click(driver, "//form[@id='ChangeDefaultPassword']/div[2]/div[5]/div/div/div/span/span/span", "xpath");
            Thread.Sleep(100);

            SetMethods.Click(driver, "//div[@id='TimeZone-list']/span/input", "xpath");
            Thread.Sleep(100);
            //driver.FindElement(By.XPath("//div[@id='TimeZone-list']")).FindElement(By.XPath("//div[@id='TimeZone-list']/span/input")).SendKeys("5"+":"+"30");
            SetMethods.EnterText(driver, "//div[@id='TimeZone-list']/span/input", "5:30", "xpath");
            Thread.Sleep(100);
            SetMethods.Click(driver, "//ul[@id='TimeZone_listbox']/li", "xpath");

            // Click submit Password button
            Thread.Sleep(2000);
            SetMethods.Click(driver, "//button[@id='submitPassword']", "xpath");
        }



    }
}
﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Selenium_WebDriver
{
    public class Suppliers
    {
        private IWebDriver driver;

        public Suppliers(IWebDriver driver)
        {
            this.driver = driver;
        }
        public void createSupplier(int load)
        {
            Thread.Sleep(1000);
            SetMethods.Click(driver, "layout_supp_a", "id");
            SetMethods.Click(driver, "//div[@id='SuppliersGrid']/div/div/a/i", "xpath");
            SetMethods.Click(driver, "Name", "id");
            SetMethods.EnterText(driver, "Name", RandomStringGenerators.randomStringGenerator(6, "caps").ToString(), "id");
            SetMethods.Click(driver, "EmailId", "id");
            SetMethods.EnterText(driver, "EmailId", RandomStringGenerators.randomEmailGenerator(7).ToString(), "id");
            SetMethods.Click(driver, "Website", "id");
            SetMethods.EnterText(driver, "Website", "www." + RandomStringGenerators.randomStringGenerator(7, "small").ToString() + ".com", "id");
            SetMethods.Click(driver, "Industry", "id");
            SetMethods.EnterText(driver, "Industry", RandomStringGenerators.randomStringGenerator(6, "caps").ToString(), "id");
            //write Calender code here...
            SetMethods.Click(driver, "//div[@id='tab1']/div[2]/div[3]/div/div/span[1]/span/span[1]", "xpath");
            Thread.Sleep(100);
            driver.FindElement(By.XPath("//div[@id='Size-list']")).FindElement(By.XPath("//ul[@id='Size_listbox']/li[5]")).Click();

            SetMethods.Click(driver, "PrimaryPhone", "id");
            SetMethods.EnterText(driver, "PrimaryPhone", "+918998989899", "id");
            SetMethods.Click(driver, "//a[contains(text(),'Next')]", "xpath");
            Thread.Sleep(1000);

            //create a address by using address search box in adding address page with a load '3'
            Address address = new Address(driver);
            address.AddressEntryByEachColumn(2);

            SetMethods.Click(driver, "//a[contains(text(),'Next')]", "xpath");
            Thread.Sleep(100);

            IJavaScriptExecutor jse = (IJavaScriptExecutor)driver;
            jse.ExecuteScript("document.getElementById('CreditLimit').value='4567890';");
            jse.ExecuteScript("document.getElementById('CreditLimit').focus();");
            jse.ExecuteScript("document.getElementById('CreditLimit').click();");

            Thread.Sleep(200);
            SetMethods.Click(driver, "//div[@id='tab3']/div/div[2]/div/div", "xpath");
            Thread.Sleep(100);
            driver.FindElement(By.XPath("//div[@id='CurrencyId-list']")).FindElement(By.XPath("//ul[@id='CurrencyId_listbox']/li[2]")).Click();

            SetMethods.Click(driver, "//a[contains(text(),'Next')]", "xpath");
            Thread.Sleep(100);
            SetMethods.Click(driver, "//div[@id='tab4']/div/div[1]/span/span/span[1]", "xpath");
            Thread.Sleep(100);
            SetMethods.Click(driver, "//ul[@id='ddlSelectSupplierCategoryList_listbox']/li[2]", "xpath");
            SetMethods.Click(driver, "undo_redo_rightAll", "id");
            Thread.Sleep(100);
            SetMethods.Click(driver, "//div[@id='tab4']/div/div/span/span/span", "xpath");
            Thread.Sleep(100);
            SetMethods.Click(driver, "//ul[@id='ddlSelectSupplierCategoryList_listbox']/li[3]", "xpath");
            //By.Id("undo_redo_rightSelected")) for specific selection
            //By.Id("undo_redo_rightAll")) for all selection
            SetMethods.Click(driver, "undo_redo_rightAll", "id");
            SetMethods.Click(driver, "//a[contains(text(),'Next')]", "xpath");
            Thread.Sleep(2000);
            SetMethods.Click(driver, "//a[contains(text(),'Save')]", "xpath");
            Thread.Sleep(2500);
            //SetMethods.Click(driver, "//dl[@id='Services']/span/dd", "xpath");
            //Thread.Sleep(500);
            SetMethods.Click(driver, "//div[@id='SuppliersContactGrid']/div/div/a/i", "xpath");

            //create a contact
            Thread.Sleep(2000);
            Contact contact = new Contact(driver);
            contact.ContactCreate();
            Thread.Sleep(2000);
        }
    }
}

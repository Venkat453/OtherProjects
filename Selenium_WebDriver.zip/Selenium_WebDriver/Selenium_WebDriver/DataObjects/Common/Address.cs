﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Selenium_WebDriver
{
    public class Address
    {
        private IWebDriver driver;

        public Address(IWebDriver driver)
        {
            this.driver = driver;
            ExcelUtility excelutil = new ExcelUtility("./MockData.xlsx", "Address");
            ExcelUtility.DataPopulateInCollection();
            var rowsCount = ExcelUtility.DataCount();
        }
        
        public void AddressEntryByEachColumn(int load)
        {
            for (int i = 1; i <= load; i++)
            {
                Thread.Sleep(500);
                SetMethods.Clear(driver, "Line1", "id");
                SetMethods.EnterText(driver, "Line1", ExcelUtility.ReadData(i, "Line1").ToString(), "id");
                Thread.Sleep(50);
                SetMethods.Clear(driver, "Country", "id");
                SetMethods.EnterText(driver, "Country", ExcelUtility.ReadData(i, "Country").ToString(), "id");
                Thread.Sleep(50);
                SetMethods.Clear(driver, "City", "id");
                SetMethods.EnterText(driver, "City", ExcelUtility.ReadData(i, "City").ToString(), "id");
                Thread.Sleep(50);
                SetMethods.Clear(driver, "PostalCode", "id");
                SetMethods.EnterText(driver, "PostalCode", ExcelUtility.ReadData(i, "PostalCode").ToString(), "id");
                if (i < load)
                {
                    Thread.Sleep(1000);
                    SetMethods.Click(driver, "AddAddressBtn", "id");
                }
                Thread.Sleep(2000);
            }
        }

        public void AddressEntryBySearchBox(int load)
        {
            for (int i = 1; i <= load; i++)
            {
                Thread.Sleep(3000);
                driver.FindElement(By.Id("geocomplete")).Click();
                Thread.Sleep(2000);
                driver.FindElement(By.Id("geocomplete")).SendKeys(RandomStringGenerators.randomStringGenerator(3, "numeric").ToString());
                Thread.Sleep(500);
                driver.FindElement(By.Id("geocomplete")).SendKeys(Keys.Down);
                driver.FindElement(By.Id("geocomplete")).SendKeys(Keys.Down);
                driver.FindElement(By.Id("geocomplete")).SendKeys(Keys.Down);
                Thread.Sleep(500);
                driver.FindElement(By.Id("geocomplete")).SendKeys(Keys.Tab);
                if (i < load)
                {
                    Thread.Sleep(1000);
                    driver.FindElement(By.Id("AddAddressBtn")).Click();
                }
                Thread.Sleep(2000);
            }
        }

        public void AddressEntryByMultiSelect(int load)
        {
            for (int i = 0; i < load; i++)
            {
                Thread.Sleep(3000);
            }
        }
    }
}

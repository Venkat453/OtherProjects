﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Selenium_WebDriver
{
    public class Contact
    {
        private IWebDriver driver;

        public Contact(IWebDriver driver)
        {
            this.driver = driver;
        }

        public void ContactCreate()
        {
            driver.FindElement(By.Id("Contact_FirstName")).Click();
            driver.FindElement(By.Id("Contact_FirstName")).Clear();
            driver.FindElement(By.Id("Contact_FirstName")).SendKeys(RandomStringGenerators.randomStringGenerator(5, "small").ToString());
            driver.FindElement(By.Id("Contact_MiddleName")).Clear();
            driver.FindElement(By.Id("Contact_MiddleName")).SendKeys(RandomStringGenerators.randomStringGenerator(5, "small").ToString());
            driver.FindElement(By.Id("Contact_LastName")).Clear();
            driver.FindElement(By.Id("Contact_LastName")).SendKeys(RandomStringGenerators.randomStringGenerator(5, "small").ToString());
            driver.FindElement(By.Name("Contact.Title_input")).Clear();
            driver.FindElement(By.Name("Contact.Title_input")).SendKeys("Company manager");
            driver.FindElement(By.Name("Contact.Title_input")).SendKeys(Keys.Down);
            driver.FindElement(By.Name("Contact.Title_input")).SendKeys(Keys.Down);
            driver.FindElement(By.Name("Contact.Title_input")).SendKeys(Keys.Down);
            driver.FindElement(By.Name("Contact.Title_input")).SendKeys(Keys.Tab);
            driver.FindElement(By.Id("Contact_Email")).Clear();
            driver.FindElement(By.Id("Contact_Email")).SendKeys(RandomStringGenerators.randomEmailGenerator(8).ToString());
            driver.FindElement(By.Id("Contact_SecondaryEmail")).Click();
            driver.FindElement(By.Id("Contact_SecondaryEmail")).Clear();
            driver.FindElement(By.Id("Contact_SecondaryEmail")).SendKeys(RandomStringGenerators.randomEmailGenerator(8).ToString());
            driver.FindElement(By.Id("Contact_Website")).Click();
            driver.FindElement(By.Id("Contact_Website")).Clear();
            driver.FindElement(By.Id("Contact_Website")).SendKeys(RandomStringGenerators.randomStringGenerator(6, "small").ToString() + ".com");
            driver.FindElement(By.Id("Contact_PrimaryPhone")).Click();
            driver.FindElement(By.Id("Contact_PrimaryPhone")).Clear();
            driver.FindElement(By.Id("Contact_PrimaryPhone")).SendKeys("+919898899889");
            driver.FindElement(By.Id("Contact_SecondaryPhone")).Click();
            driver.FindElement(By.Id("Contact_SecondaryPhone")).Clear();
            driver.FindElement(By.Id("Contact_SecondaryPhone")).SendKeys("+918998989898");
            driver.FindElement(By.Id("Contact_FaxNumber")).Click();
            driver.FindElement(By.Id("Contact_FaxNumber")).Clear();
            driver.FindElement(By.Id("Contact_FaxNumber")).SendKeys("+918998989898");

            driver.FindElement(By.Id("NextTab")).Click();
            Thread.Sleep(1000);

            //create a address by using address search box in adding address page with a load '3'
            Address contactAddress = new Address(driver);
            contactAddress.AddressEntryByEachColumn(3);
            Thread.Sleep(1000);

            driver.FindElement(By.XPath("//a[contains(text(),'Next')]")).Click();
            Thread.Sleep(2000);

            driver.FindElement(By.XPath("//a[contains(text(),'Save')]")).Click();
            Thread.Sleep(3000);

        }

    }
}

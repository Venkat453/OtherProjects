﻿using log4net;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Selenium_WebDriver
{
    public class Program
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(Program));
        private const int Load = 2;
        static void Main(string[] args)
        {
            IWebDriver driver = new ChromeDriver();

            Registration registration = new Registration(driver);
            registration.Register(Load);

            //TestStartUp startUp = new TestStartUp(driver);
            //startUp.testStartUp();


            Stakeholders stakeholder = new Stakeholders(driver);
            for (int i = 1; i <= Load; i++)
            {
                ExcelUtility excelutil = new ExcelUtility("./MockData.xlsx", "Stakeholders");
                ExcelUtility.DataPopulateInCollection();
                stakeholder.StakeholderCreate(i);
            }

            Suppliers supplier = new Suppliers(driver);
            for (int j = 1; j <= Load; j++)
            {
                //ExcelUtility excelutil = new ExcelUtility("./MockData.xlsx", "Stakeholders");
                //ExcelUtility.DataPopulateInCollection();
                supplier.createSupplier(j);
            }

            TestClose testClose = new TestClose(driver);
            testClose.TestCloseUp();


            //ExcelUtility excelutil = new ExcelUtility("./MockData.xlsx", "sheet1");
            //ExcelUtility.DataPopulateInCollection();
            //var rowsCount = ExcelUtility.DataCount();
            //for (int i = 1; i <= rowsCount; i++)
            //{
            //    Console.WriteLine($"first_name:{ExcelUtility.ReadData(i, "first_name")} and last_name: {ExcelUtility.ReadData(i, "last_name")}");
            //}
            //Console.ReadKey();


            // for logs...
            //log.Info("Hello logging world...! This is Selenium Functional testing...");
        }
    }
}
